const { REST, Routes } = require("discord.js");

const commands = [
  {
    name: "ping",
    description: "Replies with Pong!",
  },
];

const rest = new REST({ version: "10" }).setToken(
  "MTI3OTMxNzY2ODMzNTQ1NjI1Nw.GC53Pe.7tQMQVGwcEn091FtUB90ASDb18UFa05W1dF434"
);

try {
  console.log("Started refreshing application (/) commands.");
  rest.put(Routes.applicationCommands("1279317668335456257"), {
    body: commands,
  });

  console.log("Successfully reloaded application (/) commands.");
} catch (error) {
  console.error(error);
}
