const { Client, GatewayIntentBits } = require("discord.js");

//  what are the permission you are giving to it
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.on("messageCreate", (message1) => {
  if (message1.author.bot) return;
  if (message1.content.startsWith("create")) {
    const url = message1.content.split("create")[1];
    return message1.reply({
      content: "generate a Short ID for " + url,
    });
  }
  message1.reply({
    content: "Ciao!",
  });
});

client.on("interactionCreate", (interaction) => {
  console.log(interaction);
  interaction.reply("Pong!");
});

client.login(
  "MTI3OTMxNzY2ODMzNTQ1NjI1Nw.GC53Pe.7tQMQVGwcEn091FtUB90ASDb18UFa05W1dF434"
);
